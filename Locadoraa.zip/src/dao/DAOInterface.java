
package dao;

import dto.Cliente;
import dto.Midia;
import dto.Status;
import java.util.ArrayList;
import dto.MidiaEmprestada;

public interface DAOInterface {
    Cliente getClientePelaMatricula(int matricula);
    Cliente get(int index);
    ArrayList<Cliente> listar();
    void salvar(Cliente cliente);
    int gerarMatriculaValida();
    void remover(int matricula);
    Boolean temMidiaEmprestada();
    Boolean estaDisponivel(int quantidade);
    void AnoMidia(int ano);
    void AnoMidia(int ano, int codigo);
    void salvarMidia(Midia midia);
    Midia getMidiaPeloCodigo(int codigo);
    void remove(int codigo);
    Midia getMidia(int index);
    ArrayList<Midia> listarMidia();
    int gerarCodigoValido();
    int getPreco(Status status);
    void salvarMidiaE(MidiaEmprestada midiaEmprestada);
    ArrayList<MidiaEmprestada> listarMidiaE();
    MidiaEmprestada getMidiaEmprestadaPeloCodigoDaMidiaECliente(int midiaCodigo, int clienteCodigo);
    void removeMidiaE(int midiaCodigo, int clienteCodigo);
    void setMidiasEmprestadas(ArrayList<MidiaEmprestada> aMidiasEmprestadas);
}
