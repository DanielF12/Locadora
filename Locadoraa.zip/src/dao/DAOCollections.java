package dao;
import java.util.ArrayList;
import dto.Cliente;
import dto.Midia;
import dto.Status;
import dto.MidiaEmprestada;

/**
 * @author udesc
 */
public class DAOCollections implements DAOInterface {
    
    private static DAOCollections instance = null;
    private ArrayList<Cliente> clientes;
    private ArrayList<Midia> midias;
    private ArrayList<MidiaEmprestada> midiasEmprestadas;

    private DAOCollections() {
        clientes = new ArrayList();
    }

    public static synchronized DAOCollections getInstance() {
        if (instance == null)
            instance = new DAOCollections();
        return instance;
    }
    
    @Override
    public Cliente getClientePelaMatricula(int matricula) {
        for(Cliente cliente : listar()) {
            if (cliente.getMatricula() == matricula) return cliente;
        }
        return null;
    }
    
    
    @Override
    public Cliente get(int index) {
        return clientes.get(index);
    }
    
    @Override
    public  ArrayList<Cliente> listar() {
        return clientes;
    }
    
    @Override
    public void salvar(Cliente cliente) {
        clientes.add(cliente);
    }
    
    //@Override
   // public String getNome() {
    //    return getNome();
    //}
    
    @Override
    public int gerarMatriculaValida() {
         if (listar().size() == 0) return 0;
        Cliente ultimoCliente = clientes.get(clientes.size() - 1);
        return ultimoCliente.getMatricula() + 1;
    }
    
    @Override
    public void remover(int matricula) {
        Cliente cliente = getClientePelaMatricula(matricula);
        clientes.remove(cliente);
    }
    
    
    @Override
   public Boolean temMidiaEmprestada() {
       int matricula = 0;
        for(MidiaEmprestada midiaEmprestada : MidiaEmprestada.listarMidiaE()) {
            if (midiaEmprestada.getClienteCodigo() == matricula) {
                return true;
            }
        }
        return false;        
    }
    
    @Override
    public Boolean estaDisponivel(int quantidade) {
        if (quantidade > 0) {
            return true;
        }
        
        return false;
    }
    
    //public Boolean lancamento() {
      //  int ano = 0;
       // if (ano == 2018) {
        //    return true;
        //}
        
      //  return false;
    //}
    
    @Override
    public void AnoMidia(int ano){
        Status status = null;
         if(status == Status.LANÇAMENTO){
            System.out.println("Esta mídia é nova, de " + ano);
         }
    }
    
    @Override
    public void AnoMidia(int ano, int codigo){
        Status status = null;
        if(status == Status.NÃOLANÇAMENTO){
            System.out.println("Esta mídia é antiga, de " + ano + ",seu codigo é: " + codigo + ", leve mais de um!");
        }
    }
    
    @Override
    public void salvarMidia(Midia midia) {
        midias.add(midia);
    }
    
    @Override
    public Midia getMidiaPeloCodigo(int codigo) {
        for (Midia midia : midias) {
            if (midia.codigo == codigo) return midia;
        }
        
        return null;
    }
    
    /**
     *
     * @param codigo
     */
    
    @Override
    public void remove(int codigo) {
        Midia midia = Midia.getMidiaPeloCodigo(codigo);
        midias.remove(codigo);
    }
    
    @Override
    public Midia getMidia(int index) {
        return midias.get(index);
    }
    
    @Override
    public ArrayList<Midia> listarMidia() {
        return midias;
    }
    
    
    @Override
    public int gerarCodigoValido() {
        if (listarMidia().size() == 0) return 0;
        
        
        Midia ultimaMidia = Midia.getMidia(listar().size() - 1);
        return ultimaMidia.codigo + 1;
    }
    
    @Override
    public int getPreco(Status status) {
        for (Midia midia : listarMidia()) {
            return midia.getPreco();
        }
        return 0;
    }   
    @Override
    public void salvarMidiaE(MidiaEmprestada midiaEmprestada) {
        midiasEmprestadas.add(midiaEmprestada);
    }
    
    @Override
    public ArrayList<MidiaEmprestada> listarMidiaE() {
        return midiasEmprestadas;
    }
    
    @Override
    public MidiaEmprestada getMidiaEmprestadaPeloCodigoDaMidiaECliente(int midiaCodigo, int clienteCodigo) {
        for (MidiaEmprestada midiaEmprestada : listarMidiaE()) {
             return midiaEmprestada;
        }
        return null;
    }
        
    @Override
    public void removeMidiaE(int midiaCodigo, int clienteCodigo) {
        MidiaEmprestada midiaEmprestada = getMidiaEmprestadaPeloCodigoDaMidiaECliente(midiaCodigo, clienteCodigo);
        midiasEmprestadas.remove(midiaEmprestada);
    }

    @Override
    public void setMidiasEmprestadas(ArrayList<MidiaEmprestada> aMidiasEmprestadas) {
        midiasEmprestadas = aMidiasEmprestadas;
    }
}
