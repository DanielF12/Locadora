package locadora.telas;

import java.util.ArrayList;
import locadora.telas.Login;

public class Locadora {
    
    public static void main(String[] args) {
        Login tela = new Login();
        tela.setVisible( true );        
    }  
}
