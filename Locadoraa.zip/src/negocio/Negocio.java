
package negocio;

import dao.DAOCollections;
import dao.DAOInterface;
import dto.Cliente;
import dto.Midia;
import dto.Status;
import java.util.ArrayList;
import dto.MidiaEmprestada;

public class Negocio {
    
    static DAOInterface dao = DAOCollections.getInstance();
    
    public static Cliente getClientePelaMatricula(int matricula) {
        return dao.getClientePelaMatricula(matricula);
    }
        
    public static Cliente get(int index) {
        return dao.get(index);
    }
    
    public static ArrayList<Cliente> listar() {
        return dao.listar();
    }
    
    public static void salvar(Cliente cliente) {
        //clientes.add(cliente);
        dao.salvar(cliente);
    }
    
    //@Override
   // public String getNome() {
    //    return getNome();
    //}
    
    public static int gerarMatriculaValida() {
         return dao.gerarMatriculaValida();
    }
    
    public static void remover(int matricula) {
        dao.remover(matricula);
    }
    
    public static Boolean temMidiaEmprestada() {
        return dao.temMidiaEmprestada();
    }
    
    public static Boolean estaDisponivel(int quantidade) {
       return dao.estaDisponivel(quantidade);
    }
    
    //public Boolean lancamento() {
      //  int ano = 0;
       // if (ano == 2018) {
        //    return true;
        //}
        
      //  return false;
    //}
    
    public static void AnoMidia(int ano){
        dao.AnoMidia(ano);
    }
    
    public static void AnoMidia(int ano, int codigo){
        dao.AnoMidia(ano, codigo);
    }
    
    public static void salvarMidia(Midia midia) {
        dao.salvarMidia(midia);
    }
    
    public static Midia getMidiaPeloCodigo(int codigo) {
       return dao.getMidiaPeloCodigo(codigo);
    }
    
    /**
     *
     * @param codigo
     */
    
    public static void remove(int codigo) {
        dao.remove(codigo);
    }
    
    public static Midia getMidia(int index) {
        return dao.getMidia(index);
    }
    
    public static ArrayList<Midia> listarMidia() {
        return dao.listarMidia();
    }
    
    public static int gerarCodigoValido() {
      return dao.gerarCodigoValido();
    }
    
    public static int getPreco(Status status) {
        for(Midia midia : listarMidia()){
            if(midia.getAno() == 2018){
                if (status == Status.LANÇAMENTO) {
                    return 4;
                 }
            }   
        }
        return 2;
    }   
    
    public static void salvarMidiaE(MidiaEmprestada midiaEmprestada) {
        dao.salvarMidiaE(midiaEmprestada);
    }
    
    public static ArrayList<MidiaEmprestada> listarMidiaE() {
        return dao.listarMidiaE();
    }
    
    public static MidiaEmprestada getMidiaEmprestadaPeloCodigoDaMidiaECliente(int midiaCodigo, int clienteCodigo) {
        for (MidiaEmprestada midiaEmprestada : listarMidiaE()) {
            if (midiaEmprestada.getMidiaCodigo() == midiaCodigo && midiaEmprestada.getClienteCodigo() == clienteCodigo){
                return dao.getMidiaEmprestadaPeloCodigoDaMidiaECliente(midiaCodigo, clienteCodigo);
            }
        }
        return null;
    }
       
    public static void removeMidiaE(int midiaCodigo, int clienteCodigo) {
        dao.removeMidiaE(midiaCodigo, clienteCodigo);
    }

    public static void setMidiasEmprestadas(ArrayList<MidiaEmprestada> aMidiasEmprestadas) {
        dao.setMidiasEmprestadas(aMidiasEmprestadas);
    }
}
