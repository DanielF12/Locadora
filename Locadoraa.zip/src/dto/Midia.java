
package dto;

import java.util.ArrayList;

public class Midia {
    public String nome;
    public int codigo;
    public String genero;
    public int ano;
    public int quantidade;
    Status status;
    //private static Midia instance = null;
    
    private static ArrayList<Midia> midias = new ArrayList<Midia>();
    
    public Midia(String nome, int codigo, String genero, int ano, int quantidade) {
        this.nome = nome;
        this.codigo = codigo;
        this.genero = genero;
        this.ano = ano;
        this.quantidade = quantidade;
        status = Status.LANÇAMENTO;
    }
    
    //public static synchronized Midia getInstancia(){
      //  if(instance == null){
        //    instance = new Midia (nome,codigo,genero,ano,quantidade);
       // }
        //return instance;
    //}
    
    
    
    public String getNome() {
        return nome;
    }
    
    public int getAno() {
        return ano;
    }

    public String getGenero() {
        return genero;
    }
    
    public Boolean estaDisponivel() {
        if (quantidade > 0) {
            return true;
        }
        
        return false;
    }
    
   // public Boolean lancamento() {
     //   if (ano == 2018) {
       //     return true;
        //}
        
        //return false;
    //}
    
    public void AnoMidia(int ano){
         if(status == Status.LANÇAMENTO){
            System.out.println("Esta mídia é nova, de " + ano);
         }
    }
    
    public void AnoMidia(int ano, int codigo){
        if(status == Status.NÃOLANÇAMENTO){
            System.out.println("Esta mídia é antiga, de " + ano + ",seu codigo é: " + codigo + ", leve mais de um!");
        }
    }
    
    public static void salvarMidia(Midia midia) {
        midias.add(midia);
    }
    
    public static void remove(int codigo) {
        Midia midia = Midia.getMidiaPeloCodigo(codigo);
        midias.remove(codigo);
    }
    
    public static Midia getMidia(int index) {
        return midias.get(index);
    }
    
    public static ArrayList<Midia> listarMidia() {
        return midias;
    }
    
    public static Midia getMidiaPeloCodigo(int codigo) {
        for (Midia midia : midias) {
            if (midia.codigo == codigo) return midia;
        }
        
        return null;
    }
    
    public static int gerarCodigoValido() {
        if (listarMidia().size() == 0) return 0;
        
        
        Midia ultimaMidia = Midia.getMidia(listarMidia().size() - 1);
        return ultimaMidia.codigo + 1;
    }
    
    public int getPreco() {
        if(ano == 2018){
                status = Status.LANÇAMENTO;
                return 4;
        }
        status = Status.NÃOLANÇAMENTO;
        return 2;
    }
}
