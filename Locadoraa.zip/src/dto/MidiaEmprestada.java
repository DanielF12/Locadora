package dto;

import java.util.ArrayList;

public class MidiaEmprestada {
    private int clienteCodigo;
    private int midiaCodigo;
    
    private static ArrayList<MidiaEmprestada> midiasEmprestadas = new ArrayList<MidiaEmprestada>();
    
    public MidiaEmprestada(int clienteCodigo, int midiaCodigo) {
        this.setClienteCodigo(clienteCodigo);
        this.setMidiaCodigo(midiaCodigo);
    }
    
    /**
     * @return the clienteCodigo
     */
    public int getClienteCodigo() {
        return clienteCodigo;
    }

    /**
     * @param clienteCodigo the clienteCodigo to set
     */
    public void setClienteCodigo(int clienteCodigo) {
        this.clienteCodigo = clienteCodigo;
    }

    /**
     * @return the midiaCodigo
     */
    public int getMidiaCodigo() {
        return midiaCodigo;
    }

    /**
     * @param midiaCodigo the midiaCodigo to set
     */
    public void setMidiaCodigo(int midiaCodigo) {
        this.midiaCodigo = midiaCodigo;
    }

    /**
     * @param aMidiasEmprestadas the midiasEmprestadas to set
     */
    
    public static void salvarMidiaE(MidiaEmprestada midiaEmprestada) {
        midiasEmprestadas.add(midiaEmprestada);
    }
    
    public static ArrayList<MidiaEmprestada> listarMidiaE() {
        return midiasEmprestadas;
    }
    
    public static MidiaEmprestada getMidiaEmprestadaPeloCodigoDaMidiaECliente(int midiaCodigo, int clienteCodigo) {
        for (MidiaEmprestada midiaEmprestada : listarMidiaE()) {
            if (midiaEmprestada.getMidiaCodigo() == midiaCodigo && midiaEmprestada.getClienteCodigo() == clienteCodigo) return midiaEmprestada;
        }
        return null;
    }
        
    public static void removeMidiaE(int midiaCodigo, int clienteCodigo) {
        MidiaEmprestada midiaEmprestada = getMidiaEmprestadaPeloCodigoDaMidiaECliente(midiaCodigo, clienteCodigo);
        midiasEmprestadas.remove(midiaEmprestada);
    }

    public static void setMidiasEmprestadas(ArrayList<MidiaEmprestada> aMidiasEmprestadas) {
        midiasEmprestadas = aMidiasEmprestadas;
    }
}
