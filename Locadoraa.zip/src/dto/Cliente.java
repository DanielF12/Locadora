
package dto;

import java.util.ArrayList;

public class Cliente extends Pessoa {
    private int matricula;
    private int creditos;
    private String senha;
    //private static Cliente instance = null;
    
    private static ArrayList<Cliente> clientes = new ArrayList<Cliente>();
    
    public Cliente(int matricula, int creditos, String nome, String endereco, String cpf, String telefone, String senha) {
        super(nome,endereco,cpf,telefone);
        this.setMatricula(matricula);
        this.setCreditos(creditos);
        this.setSenha(senha);
    }
    
    /**
     * @return the matricula
     */
    public int getMatricula() {
        return matricula;
    }

    /**
     * @param matricula the matricula to set
     */
    public void setMatricula(int matricula) {
        this.matricula = matricula;
    }

    /**
     * @return the creditos
     */
    public int getCreditos() {
        return creditos;
    }

    /**
     * @param creditos the creditos to set
     */
    public void setCreditos(int creditos) {
        this.creditos = creditos;
    }

    /**
     * @return the senha
     */
    public String getSenha() {
        return senha;
    }

    /**
     * @param senha the senha to set
     */
    public void setSenha(String senha) {
        this.senha = senha;
    }
    //public static synchronized Cliente getInstancia(){
      //  if(instance == null){
        //    instance = new Cliente(matricula,creditos,nome,endereco,cpf,telefone,senha);
       // }
        //return instance;
    //}
    
}
