
package dto;

public class Funcionario extends Pessoa {
    private int matricula;
    private String senha;
    
    public Funcionario(int matricula, String nome, String endereco, String cpf, String telefone, String senha) {
        super(nome,endereco,cpf,telefone);
        this.setMatricula(matricula);
        this.setSenha(senha);
    }

    /**
     * @return the matricula
     */
    public int getMatricula() {
        return matricula;
    }

    /**
     * @param matricula the matricula to set
     */
    public void setMatricula(int matricula) {
        this.matricula = matricula;
    }

    /**
     * @return the senha
     */
    public String getSenha() {
        return senha;
    }

    /**
     * @param senha the senha to set
     */
    public void setSenha(String senha) {
        this.senha = senha;
    }
}
