package dto;

public enum Status {
    LANÇAMENTO(1),NÃOLANÇAMENTO(0);
    
private int valor;
    
    Status(int valor){
        this.valor = valor;
    }
    
    public String tipo(){
        if(this.valor == 1){
            return "LANÇAMENTO";
        }
          return "NÃOLANÇAMENTO";
    }
}